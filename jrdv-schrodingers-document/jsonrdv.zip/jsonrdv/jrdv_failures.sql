CREATE OR REPLACE JSON RELATIONAL DUALITY VIEW hol23c.bigdoc_dv AS
  SELECT JSON {
   'teamid'    : TE.te_id
  ,'teamname'  : TE.te_name
  ,'plantings' :
    (SELECT JSON{
     'hi_key'          : PS.ps_hi_id       
    ,'te_key'          : PS.ps_te_id       
    ,'tr_key'          : PS.ps_tr_id       
    ,'tree_lat'        : PS.ps_lat         
    ,'tree_lng'        : PS.ps_lng         
    ,'plant_dt'        : PS.ps_planted_on  
    ,'height_at_start' : PS.ps_height      
    ,'notes'           : PS.ps_comments 
    }    
      FROM hol23c.planting_schedule PS       
     WHERE TE.te_id = PS.ps_te_id)
  }
  FROM hol23c.teams TE; 

/*
This command should fail, returning with ORA-40895: 

ERROR at line 19:
ORA-40895: invalid SQL expression in JSON relational duality view 
           (expected parent table has foreign key constraints to child table)

SQL> ? 40895
Message: "invalid SQL expression in JSON relational duality view (%s)"
Cause:  An invalid SQL expression was used in JSON relational duality view.
Action: Ensure that a JSON relational duality view is constructed solely
        using JSON_OBJECT and JSON_ARRAYAGG with JSON_OBJECT input.
        Joins must be expressed on key columns with referential integrity
*/
