######
# Script:  update_by_curl.sh
# Purpose: Modifies existing data elements within JRDVs by CURL PUT calls
# Author:  Jim Czuprynski (Zero Defect Computing, Inc.)
#####

# Update documents within TEAM_ASSIGNMENTS_DV
curl --request PUT --header 'Content-Type: application/json' --data-binary @/home/oracle/examples/jsonrdv/update_team_assignments.json --url http://localhost:8080/ords/hol23c/team_assignments_dv/201 

