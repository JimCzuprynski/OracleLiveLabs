/*
|| Script:  update_by_dml.sql
|| Purpose: Issues UPDATE statements directly against table(s) underlying JRDVs
|| Author:  Jim Czuprynski (Zero Defect Computing, Inc.)
*/

UPDATE hol23c.team_members
   SET tm_last_name = 'Daley'
     , tm_first_name = 'Richard'
  WHERE tm_id = 3003;

UPDATE hol23c.planting_schedule
   SET ps_planted_on = '01-JUL-23'
     , ps_height = 1.8765
     , ps_comments = 'Replanted - original tree died'
 WHERE ps_hi_id = 17031560300
    AND ps_te_id = 201
    AND ps_tr_id = 'GLTR';
 
COMMIT;
