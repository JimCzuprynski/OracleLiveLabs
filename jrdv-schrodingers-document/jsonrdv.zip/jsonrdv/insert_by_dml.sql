/*
|| Script:  insert_by_dml.sql
|| Purpose: Issues INSERT statements directly against table(s) underlying JRDVs
|| Author:  Jim Czuprynski (Zero Defect Computing, Inc.)
*/

INSERT INTO hol23c.team_members(tm_id, tm_te_id, tm_first_name, tm_last_name, tm_address, tm_city, tm_state_abbr, tm_zip_code, tm_lat, tm_lng)
VALUES (2004, 201, 'Sue', 'Relatab', '148 N. Hudson Street', 'Westmont', 'IL', '60559', 41.79994291851383, -87.98306118289261);

INSERT INTO hol23c.team_members(tm_id, tm_te_id, tm_first_name, tm_last_name, tm_address, tm_city, tm_state_abbr, tm_zip_code, tm_lat, tm_lng)
VALUES (1004, 101, 'Judy', 'Ruliani', '710 Lor Ann Street', 'South Elgin', 'IL', '60177', 41.98825611710836, -88.28512125672992);
        
COMMIT;

INSERT INTO hol23c.planting_schedule (ps_hi_id, ps_te_id, ps_tr_id, ps_planted_on, ps_height, ps_comments, ps_lng, ps_lat)
VALUES (17031560200, 301, 'ACSA1',  '21-Jun-2023', 0.975,  'Planted near Leclaire Courts rostrum', -87.749400, 41.814100);

INSERT INTO hol23c.planting_schedule (ps_hi_id, ps_te_id, ps_tr_id, ps_planted_on, ps_height, ps_comments, ps_lng, ps_lat)
VALUES (17031560200, 301, 'ACSA2',  '21-Jun-2023', 1.098,  'Planted near Leclaire Courts rostrum', -87.749250, 41.814200);

INSERT INTO hol23c.planting_schedule (ps_hi_id, ps_te_id, ps_tr_id, ps_planted_on, ps_height, ps_comments, ps_lng, ps_lat)
VALUES (17031560200, 301, 'QURU',   '21-Jun-2023', 2.684,  'Planted near Leclaire Courts rostrum', -87.749100, 41.814100);

COMMIT;
