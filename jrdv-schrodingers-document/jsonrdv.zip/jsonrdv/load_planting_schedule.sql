/* 
|| Script:  load_planting_schedule.sql
|| Purpose: Performs initial load of HOL23C.PLANTING_SCHEDULE
|| Author:  Jim Czuprynski (Zero Defect Computing, Inc.)
*/

TRUNCATE TABLE hol23c.planting_schedule;

INSERT INTO hol23c.planting_schedule (ps_hi_id, ps_te_id, ps_tr_id, ps_planted_on, ps_height, ps_comments, ps_lng, ps_lat)
VALUES (17031560300, 101, 'ACNE',  '14-Jun-2023', 0.975,  'Placed in Vittum Park', -87.748300, 41.803500);

INSERT INTO hol23c.planting_schedule (ps_hi_id, ps_te_id, ps_tr_id, ps_planted_on, ps_height, ps_comments, ps_lng, ps_lat)
VALUES (17031560300, 101, 'ACPL',  '14-Jun-2023', 1.115,  'Placed in Vittum Park', -87.748050, 41.803500);

INSERT INTO hol23c.planting_schedule (ps_hi_id, ps_te_id, ps_tr_id, ps_planted_on, ps_height, ps_comments, ps_lng, ps_lat)
VALUES (17031560300, 101, 'ACRU',  '14-Jun-2023', 2.075,  'Placed in Vittum Park', -87.747800, 41.803500);

INSERT INTO hol23c.planting_schedule (ps_hi_id, ps_te_id, ps_tr_id, ps_planted_on, ps_height, ps_comments, ps_lng, ps_lat)
VALUES (17031560300, 201, 'JUNI',  '13-Jul-2023', 0.758,  'Placed in Vittum Park', -87.748300, 41.803250);

INSERT INTO hol23c.planting_schedule (ps_hi_id, ps_te_id, ps_tr_id, ps_planted_on, ps_height, ps_comments, ps_lng, ps_lat)
VALUES (17031560300, 201, 'GLTR',  '13-Jul-2023', 2.375,  'Placed in Vittum Park', -87.748050, 41.803250);

INSERT INTO hol23c.planting_schedule (ps_hi_id, ps_te_id, ps_tr_id, ps_planted_on, ps_height, ps_comments, ps_lng, ps_lat)
VALUES (17031560300, 201, 'MO',    '13-Jul-2023', 2.875,  'Placed in Vittum Park', -87.747800, 41.803250);

COMMIT;




