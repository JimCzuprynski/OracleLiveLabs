/*
|| Script:  delete_by_jrdv.sql
|| Purpose: Issues DELETE statements directly against JRDVs. Note that instead of 
||          the underlying table's column names, we are using JRDV key labels
|| Author:  Jim Czuprynski (Zero Defect Computing, Inc.)
*/

-- Using PLANTING_ACTIVITY_DV, delete a single entry based on one of its attribute's value
DELETE FROM hol23c.planting_activity_dv DV
  WHERE DV.data.tr_key = 'MO';

COMMIT;

-- Using MEMBERS_WITHIN_TEAMS_DV, delete a single team member based on its Member ID
DELETE FROM hol23c.members_within_teams_dv DV
  WHERE DV.data.memberid = 4001;

COMMIT;

-- Using MEMBERS_WITHIN_TEAMS_DV, delete a complete set of team members based on its Team ID
DELETE FROM hol23c.members_within_teams_dv DV
  WHERE DV.data.teamid = 401;

COMMIT;

-- Using TEAM_ASSIGNMENTS_DV, attempt to delete a team and all assigned team members.
-- This will fail because some of the team ID values for the TEAM_MEMBERS table could 
-- be left as NULL values, which is not permitted!
DELETE FROM hol23c.team_assignments_dv DV
  WHERE DV.data.teamid = 301;

ROLLBACK;


