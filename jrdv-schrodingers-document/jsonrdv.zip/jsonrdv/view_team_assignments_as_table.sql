/*
|| Script:  view_team_assignments_as_table.sql
|| Purpose: Displays current state of data underlying TEAM_ASSIGNMENTS_DV JRDV
|| Author:  Jim Czuprynski (Zero Defect Computing, Inc.)
*/

-- Show data in tabular format
SELECT 
   dv.data.teamid AS team_id
  ,dv.data.member[*].memberid AS member_ids
  ,dv.data.member[*].mbr_lname AS member_last_names
  ,dv.data.member[*].mbr_zipcode AS member_zipcodes
  FROM hol23c.team_assignments_dv DV;
