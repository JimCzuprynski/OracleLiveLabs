######
# Script:  insert_by_curl.sh
# Purpose: Inserts new data into JRDVs via CURL POST calls
# Author:  Jim Czuprynski (Zero Defect Computing, Inc.)
#####

# Insert a single row into PLANTING_ACTIVITY_DV with JSON payload inline
curl --request POST --url http://localhost:8080/ords/hol23c/planting_activity_dv/ \
  --header 'Content-Type: application/json' \
  --data '{"hi_key"          : 17031560200
          ,"te_key"          : 101
          ,"tr_key"          : "ULPU"
          ,"tree_lat"        :  41.8135000
          ,"tree_lng"        : -87.749250
          ,"plant_dt"        : "2023-06-30T00:00:00"
          ,"height_at_start" : 1.987
          ,"notes"           : "Final Leclaire Courts planting" }'
          

# Insert multiple rows into PLANTING_ACTIVITY_DV with a JSON document as payload
curl --request POST --url http://localhost:8080/ords/hol23c/planting_activity_dv/ \
  --header 'Content-Type: application/json' \
  --data-binary @/home/oracle/examples/jsonrdv/add_planting_schedule.json

