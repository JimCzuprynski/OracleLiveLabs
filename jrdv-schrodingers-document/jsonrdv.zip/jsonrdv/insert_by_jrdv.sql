/*
|| Script:  insert_by_jrdv.sql
|| Purpose: Issues INSERT statements directly against JRDVs. Note that instead of 
||          the underlying table's column names, we are using JRDV key labels instead
|| Author:  Jim Czuprynski (Zero Defect Computing, Inc.)
*/

INSERT INTO hol23c.team_assignments_dv
VALUES ('{"teamid" : 401
         ,"teamname" : "Team Chamillionaire"
         ,"teamleadcontact" : 4001
         , "member" : [
           {"memberid"   : 4001
           ,"mbr_fname"  : "Edward"
           ,"mbr_lname"  : "Vrdolyak"
           ,"mbr_addr"   : "1039 W. 32nd Street"
           ,"mbr_city"   : "Chicago"
           ,"mbr_state"  : "IL"
           ,"mbr_zipcode": "60608"
           ,"mbr_lat"    :  41.83698879350216
           ,"mbr_lng"    : -87.65176517969272 }
          ,{"memberid"   : 4002
          ,"mbr_fname"  : "Sue"
          ,"mbr_lname"  : "Relatab"
          ,"mbr_addr"   : "2857 S. Quinn Street"
          ,"mbr_city"   : "Chicago"
          ,"mbr_state"  : "IL"
          ,"mbr_zipcode": "60608"
          ,"mbr_lat"    :  41.841748725446685
          ,"mbr_lng"    : -87.65099953201185 }
           ]}'
         );

COMMIT;

INSERT INTO hol23c.members_within_teams_dv
VALUES ('  {"memberid"   : 4003
           ,"mbr_fname"  : "Edward"
           ,"mbr_lname"  : "Burke"
           ,"mbr_addr"   : "1043 W. 32nd Place"
           ,"mbr_city"   : "Chicago"
           ,"mbr_state"  : "IL"
           ,"mbr_zipcode": "60608"
           ,"mbr_lat"    :  41.83528541648637
           ,"mbr_lng"    : -87.65249726411403 
           ,"teamid" : 401
           }'
         );

INSERT INTO hol23c.members_within_teams_dv
VALUES ('  {"memberid"   : 4004
           ,"mbr_fname"  : "Dominic"
           ,"mbr_lname"  : "LoPresti"
           ,"mbr_addr"   : "1059 W. 32nd Street"
           ,"mbr_city"   : "Chicago"
           ,"mbr_state"  : "IL"
           ,"mbr_zipcode": "60608"
           ,"mbr_lat"    :  41.83593692161574
           ,"mbr_lng"    : -87.6533448345205 
           ,"teamid" : 401
           }'
         );

COMMIT;

INSERT INTO hol23c.planting_activity_dv
VALUES ('{"hi_key"          : 17031560200
         ,"te_key"          : 201
         ,"tr_key"          : "FRAM"
         ,"tree_lat"        : 41.8138000
         ,"tree_lng"        : -87.749400
         ,"plant_dt"        : "2023-06-24T00:00:00"
         ,"height_at_start" : 2.093
         ,"notes"           : "Second Leclaire Courts planting" }' );

INSERT INTO hol23c.planting_activity_dv
VALUES ('{"hi_key"          : 17031560200
         ,"te_key"          : 201
         ,"tr_key"          : "PIPU"
         ,"tree_lat"        : 41.813900
         ,"tree_lng"        : -87.749250
         ,"plant_dt"        : "2023-06-24T00:00:00"
         ,"height_at_start" : 2.576
         ,"notes"           : "Second Leclaire Courts planting" }' );

INSERT INTO hol23c.planting_activity_dv
VALUES ('{"hi_key"          : 17031560200
         ,"te_key"          : 201
         ,"tr_key"          : "PIST"
         ,"tree_lat"        : 41.813800
         ,"tree_lng"        : -87.749100
         ,"plant_dt"        : "2023-06-24T00:00:00"
         ,"height_at_start" : 1.875
         ,"notes"           : "Second Leclaire Courts planting" }' );

COMMIT;

