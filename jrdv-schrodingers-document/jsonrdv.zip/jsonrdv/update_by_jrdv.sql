/*
|| Script:  update_by_jrdv.sql
|| Purpose: Issues UPDATE statements directly against JRDVs. Note that instead of 
||          the underlying table's column names, we are using JRDV key labels instead
|| Author:  Jim Czuprynski (Zero Defect Computing, Inc.)
*/

-- Update the city name for any team member matching 'Streamwood'
UPDATE hol23c.members_within_teams_dv DV
  SET data = JSON_TRANSFORM(data, SET '$.mbr_city' = 'West Streamwood')
  WHERE DV.data.mbr_city LIKE 'Streamwood%';

COMMIT;

-- Update the team name corresponding to Team #101. Note that instead of specifying
-- the Team ID, you must specify one and only one Team Member ID!
UPDATE hol23c.members_within_teams_dv DV
  SET data = JSON_TRANSFORM(data, SET '$.teamname' = 'Chicago Botanical Gardens')
  WHERE DV.data.memberid = 1001;

COMMIT;

-- Update information for several rows within the PLANTING_ACTIVITY_DV JRDV. 
-- Note the special handling for date values as selection criteria!
UPDATE hol23c.planting_activity_dv DV
  SET data = JSON_TRANSFORM(data, SET '$.height_at_start' = 3.891)
  WHERE DV.data.tree_id = 'ACNE';

UPDATE hol23c.planting_activity_dv DV
  SET data = JSON_TRANSFORM(data, SET '$.plant_dt' = '2023-06-15T00:00:00', '$.notes' = 'Corrected planting date')
  WHERE JSON_VALUE(DV.data, '$.plant_dt') = '2023-06-14T00:00:00';

COMMIT;
