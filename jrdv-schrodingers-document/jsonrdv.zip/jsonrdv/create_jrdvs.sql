/*
|| Script:  create_jrdvs.sql
|| Purpose: Builds JRDVs from multiple tables in HOL23C schema
|| Author:  Jim Czuprynski (Zero Defect Computing, Inc.)
*/

-----
-- A JRDV based on two tables, TEAMS and TEAM_MEMBERS, to create a JSON document 
-- that combines both team and member information
-----
CREATE OR REPLACE JSON RELATIONAL DUALITY VIEW hol23c.team_assignments_dv AS
  SELECT JSON {
     'teamid'   : TE.te_id
    ,'teamname' : TE.te_name
    ,'teamleadcontact' : TE.te_lead_contact
    ,'member' :  [SELECT JSON {
                   'memberid'   : TM.tm_id
                  ,'mbr_fname'  : TM.tm_first_name
                  ,'mbr_lname'  : TM.tm_last_name
                  ,'mbr_addr'   : TM.tm_address
                  ,'mbr_city'   : TM.tm_city
                  ,'mbr_state'  : TM.tm_state_abbr
                  ,'mbr_zipcode': TM.tm_zip_code
                  ,'mbr_lat'    : TM.tm_lat
                  ,'mbr_lng'    : TM.tm_lng }
                    FROM hol23c.team_members TM
                    WITH INSERT UPDATE NODELETE
                   WHERE TE.te_id = TM.tm_te_id ] }
   FROM hol23c.teams TE
   WITH INSERT UPDATE DELETE;

-----
-- Another JRDV still based on the same two tables (TEAMS and TEAM_MEMBERS), 
-- but which creates a JSON document with team information "unnested" within
-- team member information
-----
CREATE OR REPLACE JSON RELATIONAL DUALITY VIEW hol23c.members_within_teams_dv AS
  SELECT JSON { 
    'memberid'   : TM.tm_id
   ,'mbr_fname'  : TM.tm_first_name
   ,'mbr_lname'  : TM.tm_last_name
   ,'mbr_addr'   : TM.tm_address
   ,'mbr_city'   : TM.tm_city
   ,'mbr_state'  : TM.tm_state_abbr
   ,'mbr_zipcode': TM.tm_zip_code
   ,'mbr_lat'    : TM.tm_lat
   ,'mbr_lng'    : TM.tm_lng
   ,UNNEST( 
      SELECT JSON {
        'teamid'          : TE.te_id
       ,'teamname'        : TE.te_name
       ,'teamleadcontact' : TE.te_lead_contact}
        FROM hol23c.teams TE
        WITH NOINSERT UPDATE NODELETE
       WHERE TE.te_id = TM.tm_te_id) 
   }
    FROM hol23c.team_members TM
    WITH INSERT UPDATE DELETE;
    
-----
-- An even more complex JDRV based on several tables, one of which 
-- is an associative table (PLANTING_SCHEDULE) that ties together data
-- elements in TEAMS and TREES to combine these data into a single 
-- JSON document 
-----
CREATE OR REPLACE JSON RELATIONAL DUALITY VIEW hol23c.planting_activity_dv AS
  SELECT JSON {
    'hi_key'          : PS.ps_hi_id       
   ,'te_key'          : PS.ps_te_id       
   ,'tr_key'          : PS.ps_tr_id       
   ,'tree_lat'        : PS.ps_lat         
   ,'tree_lng'        : PS.ps_lng         
   ,'plant_dt'        : PS.ps_planted_on  
   ,'height_at_start' : PS.ps_height      
   ,'notes'           : PS.ps_comments    
   ,UNNEST (
      SELECT JSON {
       'teamid'   : TE.te_id
      ,'teamname' : TE.te_name
      } 
       FROM hol23c.teams TE 
       WITH NOINSERT NOUPDATE NODELETE
      WHERE TE.te_id = PS.ps_te_id)
  ,UNNEST (
      SELECT JSON {
         'tree_id'         : TR.tr_id
       , 'common_name'     : TR.tr_common_name  
       , 'scientific_name' : TR.tr_scient_name
       , 'tree_type'       : TR.tr_type         
       , 'avg_canopy'      : TR.tr_avg_crown
       , 'avg_height'      : TR.tr_avg_height
       , 'avg_max_age'     : TR.tr_avg_max_age
      } 
       FROM hol23c.trees TR
       WITH NOINSERT NOUPDATE NODELETE
      WHERE TR.tr_id = PS.ps_tr_id)
  ,UNNEST (
      SELECT JSON {
         'doc_id'   : HI.hi_id
       , 'contents' : HI.hi_doc 
      } 
       FROM hol23c.heat_islands HI
       WITH NOINSERT NOUPDATE NODELETE
      WHERE HI.hi_id = PS.ps_hi_id)
  }
  FROM hol23c.planting_schedule PS
  WITH INSERT UPDATE DELETE
;
