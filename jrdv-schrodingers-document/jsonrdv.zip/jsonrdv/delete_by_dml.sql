/*
|| Script:  delete_by_dml.sql
|| Purpose: Issues DELETE statements directly against table(s) underlying JRDVs
|| Author:  Jim Czuprynski (Zero Defect Computing, Inc.)
*/

DELETE FROM hol23c.team_members
  WHERE tm_id = 2004;

COMMIT;

DELETE FROM hol23c.planting_schedule
  WHERE ps_hi_id = 17031560200
    AND ps_te_id = 301
    AND ps_tr_id = 'ACSA2';
  
COMMIT;
