/*
|| Script:  view_team_assignments_as_json.sql
|| Purpose: Displays current state of data underlying TEAM_ASSIGNMENTS_DV JRDV
|| Author:  Jim Czuprynski (Zero Defect Computing, Inc.)
*/

-- See all data within the JRDV
SET PAGESIZE 5000
SET LINESIZE 80
COL team_assignments HEADING "JSON (PRETTY)"

SELECT 
  JSON_SERIALIZE(data PRETTY) AS team_assignments
  FROM hol23c.team_assignments_dv;
