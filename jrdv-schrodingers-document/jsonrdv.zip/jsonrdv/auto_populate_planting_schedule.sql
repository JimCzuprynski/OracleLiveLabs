/*
|| Script:  auto_populate_planting_schedule.sql
|| Purpose: Populates PLANTING_SCHEDULE table with additional tree planting data
||          so TPS APEX application displays significant data for review
|| Author:  Jim Czuprynski (Zero Defect Computing, Inc.)
*/

-----
-- Create and populate table for initial spots from which to auto-populate plantings:
-----
DROP TABLE IF EXISTS hol23c.planting_centroids;
CREATE TABLE IF NOT EXISTS hol23c.planting_centroids (	
   pc_hi_id        NUMBER(11,0)     NOT NULL
  ,pc_lat          NUMBER(20,15)    NOT NULL
  ,pc_lng          NUMBER(20,15)    NOT NULL
  ,pc_direction    VARCHAR2(08)     NOT NULL
  ,pc_comments     VARCHAR2(60)
);

TRUNCATE TABLE hol23c.planting_centroids;

INSERT INTO hol23c.planting_centroids VALUES(17031560900, 41.798608, -87.788974, 'N2S',  'Byrne Elementary schoolchildren helped');
INSERT INTO hol23c.planting_centroids VALUES(17031561100, 41.788056, -87.779859, 'N2S',  'Near Wentworth Park');
INSERT INTO hol23c.planting_centroids VALUES(17031560800, 41.792487, -87.779464, 'W2E',  'Along 55th Street');
INSERT INTO hol23c.planting_centroids VALUES(17031820700, 41.815129, -87.787759, 'DIAG', 'Stickney park, diagonal plantings');
INSERT INTO hol23c.planting_centroids VALUES(17031840700, 41.856486, -87.693334, 'N2S',  'Near Douglass Park');
INSERT INTO hol23c.planting_centroids VALUES(17031832900, 41.874284, -87.662707, 'W2E',  'Harrison Street');
INSERT INTO hol23c.planting_centroids VALUES(17031833300, 41.869024, -87.655007, 'W2E',  'Near May Street');
INSERT INTO hol23c.planting_centroids VALUES(17031600400, 41.839908, -87.646083, 'W2E',  'Along 30th Street');
INSERT INTO hol23c.planting_centroids VALUES(17031840100, 41.842220, -87.638348, 'N2S',  'Near Canal Street');

COMMIT;

-----
-- Create package to populate table for initial spots from which to auto-populate plantings:
-----
CREATE OR REPLACE PACKAGE hol23c.pkg_populate_planting_schedule
/*
|| Package:         PKG_POPULATE_PLANTING_SCHEDULE
|| Version:         23.2.0.0.0
|| Description:     Populates PLANTING_SCHEDULE table with simulated tree plantings
||                  in specific geographic locations of known heat islands based on
||                  an identified latitude-longitude starting point
|| Author:          Jim Czuprynski - Zero Defect Computing, Inc.
*/
IS
    PROCEDURE LoadPlantingSchedules(
      dtEndDate   DATE    DEFAULT '31-MAY-23'
     ,nDaysBack   NUMBER  DEFAULT 1
    ); 

END pkg_populate_planting_schedule;  
/

CREATE OR REPLACE PACKAGE BODY hol23c.pkg_populate_planting_schedule
/*
|| Package Body:    PKG_POPULATE_PLANTING_SCHEDULE
|| Version:         23.2.0.0.0
|| Description:     Populates PLANTING_SCHEDULE table with simulated tree plantings
||                  in specific geographic locations of known heat islands based on
||                  an identified latitude-longitude starting point
|| Author:          Jim Czuprynski - Zero Defect Computing, Inc.
*/
IS

    PROCEDURE LoadPlantingSchedules(
      dtEndDate   DATE    DEFAULT '31-MAY-23'
     ,nDaysBack   NUMBER  DEFAULT 1
    )
    /*
    || Procedure:   LoadPlantingSchedule
    || Purpose:     Creates a random number of entries for PLANTING_SCHEDULE
    || Scope:       Public
    */
    IS

      -- Control variables
      midx  PLS_INTEGER   := 0;
      nReps PLS_INTEGER   := 0;

      -----
      -- Cursors
      -----
      CURSOR curPlantingCentroids IS
        SELECT pc_hi_id, pc_lat, pc_lng, pc_direction, pc_comments
          FROM hol23c.planting_centroids;

      -----
      -- Simulated data placeholders:
      -----
      vcDirection     VARCHAR2(08);
      nHiID           HOL23C.PLANTING_SCHEDULE.PS_HI_ID%TYPE;
      nRndTeamID      HOL23C.PLANTING_SCHEDULE.PS_TE_ID%TYPE;
      vcRndTreeID     HOL23C.PLANTING_SCHEDULE.PS_TR_ID%TYPE;
      dtRndDate       HOL23C.PLANTING_SCHEDULE.PS_PLANTED_ON%TYPE;
      nRndHeight      HOL23C.PLANTING_SCHEDULE.PS_HEIGHT%TYPE;
      vcComments      HOL23C.PLANTING_SCHEDULE.PS_COMMENTS%TYPE;
      nPSLat          HOL23C.PLANTING_SCHEDULE.PS_LAT%TYPE;
      nPSLng          HOL23C.PLANTING_SCHEDULE.PS_LNG%TYPE;

    BEGIN

      FOR pc IN curPlantingCentroids
        LOOP
          nHiID := pc.pc_hi_id;
          vcDirection := pc.pc_direction;
          vcComments := pc.pc_comments;
          midx := 0;

          FOR nReps IN 1..ROUND(DBMS_RANDOM.VALUE(3,12),0)
            
            LOOP 
              midx := midx + 1;

              nRndTeamID := 
                CASE ROUND(DBMS_RANDOM.VALUE(1,3),0)
                  WHEN 1 THEN 101
                  WHEN 2 THEN 201
                  WHEN 3 THEN 301
                  ELSE 0
                END;
                
              vcRndTreeID := 
                CASE ROUND(DBMS_RANDOM.VALUE(1,10),0)
                  WHEN 1 THEN 'ACNE'
                  WHEN 2 THEN 'PYCA_B'
                  WHEN 3 THEN 'MO'
                  WHEN 4 THEN 'TIAM' 
                  WHEN 5 THEN 'ACSA2'
                  WHEN 6 THEN 'FRPE'
                  WHEN 7 THEN 'PIPU'
                  WHEN 8 THEN 'JUNI'
                  WHEN 9 THEN 'PODE'
                 ELSE 'ULPU'
                END;
            
              dtRndDate    := dtEndDate + ROUND(DBMS_RANDOM.VALUE(1,90),0); 
              nRndHeight   := ROUND((DBMS_RANDOM.VALUE(500,3000) / 1000),4);
          
              CASE vcDirection
                WHEN 'W2E' THEN
                  -- Keep latitude constant, but vary longitude
                  nPSLat := pc.pc_lat;
                  nPSLng := pc.pc_lng + (midx * 0.000075);
                WHEN 'N2S' THEN
                  -- Keep longitude constant, but vary latitude
                  nPSLat := pc.pc_lat - (midx * 0.000075);
                  nPSLng := pc.pc_lng;
                WHEN 'DIAG' THEN
                  -- Vary both latitude and longitude
                  nPSLat := pc.pc_lat - (midx * 0.000050);
                  nPSLng := pc.pc_lng - (midx * 0.000050);
                ELSE
                  DBMS_OUTPUT.PUT_LINE('Missing Direction Type!!');
              END CASE;
  
              INSERT INTO hol23c.planting_schedule(
               ps_hi_id        
              ,ps_te_id        
              ,ps_tr_id        
              ,ps_planted_on   
              ,ps_height       
              ,ps_comments     
              ,ps_lat          
              ,ps_lng)
              VALUES(
               nHiID
              ,nRndTeamID
              ,vcRndTreeID
              ,dtRndDate
              ,nRndHeight
              ,vcComments
              ,nPSLat
              ,nPSLng);
  
            COMMIT;

        END LOOP;

      END LOOP;

    EXCEPTION
      WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Unexpected fatal error during PLANTING_SCHEDULE population: ' || SQLCODE || ' - ' || SQLERRM);
        ROLLBACK;

    END LoadPlantingSchedules;

END pkg_populate_planting_schedule;
/

-----
-- Populate PLANTING_SCHEDULE with sufficient additional data:
-----
SET SERVEROUTPUT ON
DELETE FROM planting_schedule 
WHERE ps_hi_id IN (SELECT DISTINCT pc_hi_id FROM planting_centroids);
COMMIT;
BEGIN
    pkg_populate_planting_schedule.loadplantingschedules;
END;
/
