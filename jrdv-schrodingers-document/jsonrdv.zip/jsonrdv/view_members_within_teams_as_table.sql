/*
|| Script:  view_members_within_teams_as_table.sql
|| Purpose: Displays current state of data underlying MEMBERS_WITH_TEAMS_DV JRDV
|| Author:  Jim Czuprynski (Zero Defect Computing, Inc.)
*/

-- Show data in tabular format
SELECT 
  dv.data.teamid AS teamid
, dv.data.teamname AS teamname
, dv.data.memberid AS memberid
, dv.data.mbr_lname || ', ' || dv.data.mbr_fname AS full_name
, dv.data.mbr_addr || ', ' || dv.data.mbr_city || ', ' || dv.data.mbr_state || ' ' || dv.data.mbr_zipcode AS full_address
  FROM hol23c.members_within_teams_dv DV;

