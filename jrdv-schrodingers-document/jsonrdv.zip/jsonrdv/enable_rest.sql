/*
|| Script:  enable_rest.sql
|| Purpose: Enables REST for HOL23C schema and selected JRDVs
|| Author:  Jim Czuprynski (Zero Defect Computing, Inc.)
*/

DECLARE
  PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
    -- Enable the HOL23c schema for ORDS REST ...
    ORDS.ENABLE_SCHEMA(p_enabled => TRUE,
                       p_schema => 'HOL23C',
                       p_url_mapping_type => 'BASE_PATH',
                       p_url_mapping_pattern => 'hol23c',
                       p_auto_rest_auth => FALSE);

    -- ... and all JRDVs as well
    ORDS.ENABLE_OBJECT(p_enabled => TRUE,
                       p_schema => 'HOL23C',
                       p_object => 'TEAM_ASSIGNMENTS_DV',
                       p_object_type => 'VIEW',
                       p_object_alias => 'team_assignments_dv',
                       p_auto_rest_auth => FALSE);
    ORDS.ENABLE_OBJECT(p_enabled => TRUE,
                       p_schema => 'HOL23C',
                       p_object => 'MEMBERS_WITHIN_TEAMS_DV',
                       p_object_type => 'VIEW',
                       p_object_alias => 'members_within_teams_dv',
                       p_auto_rest_auth => FALSE);
    ORDS.ENABLE_OBJECT(p_enabled => TRUE,
                       p_schema => 'HOL23C',
                       p_object => 'PLANTING_ACTIVITY_DV',
                       p_object_type => 'VIEW',
                       p_object_alias => 'planting_activity_dv',
                       p_auto_rest_auth => FALSE);

    COMMIT;

END;
/
