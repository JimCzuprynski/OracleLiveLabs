/*
|| Script:  create_apex_environment.sql
|| Purpose: Creates new APEX workspace and imports TPS application
|| Author:  Jim Czuprynski (Zero Defect Computing, Inc.)
*/

-----
-- Set session environment:
-----
ALTER SESSION SET CONTAINER = freepdb1;
ALTER SESSION SET CURRENT_SCHEMA = APEX_230100;

SET SERVEROUTPUT ON
DECLARE
    tablespace_exists PLS_INTEGER := 0;
BEGIN

    -----
    -- Remove workspace, if it exists:
    -----
    BEGIN
        SELECT 1 INTO tablespace_exists
          FROM apex_workspaces 
         WHERE workspace = 'TPS';
    
       IF tablespace_exists > 0 THEN
            DBMS_OUTPUT.PUT_LINE('TPS tablespace exists! It will be removed and replaced.');
            APEX_INSTANCE_ADMIN.REMOVE_WORKSPACE(
                p_workspace => 'TPS'
               ,p_drop_users => 'N'
               ,p_drop_tablespaces => 'N');
       END IF;
    
    
    EXCEPTION
        WHEN NO_DATA_FOUND THEN   
            NULL;
        WHEN OTHERS THEN   
            DBMS_OUTPUT.PUT_LINE('Error checking existence of tablespace TPS - investigate immediately: ' || SQLCODE || ' - ' || SQLERRM);

    END;

    -----
    -- Create new TPS workspace, assigning it to HOL23C schema
    -----
    BEGIN
        APEX_INSTANCE_ADMIN.ADD_WORKSPACE (
            p_workspace => 'TPS'
           ,p_primary_schema => 'HOL23C'
           ,p_additional_schemas => 'HOL23C');

    EXCEPTION
        WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE('Error while creating TPS tablespace - investigate immediately: ' || SQLCODE || ' - ' || SQLERRM);

    END;

    -----
    -- Create user for new workspace:
    ----
    BEGIN

        APEX_UTIL.SET_WORKSPACE(p_workspace => 'TPS');
        APEX_UTIL.CREATE_USER (
            p_user_name => 'ADMIN'
           ,p_web_password => 'Welcome123#'
           ,p_change_password_on_first_use  => 'N'
           ,p_default_schema => 'HOL23C'
           ,p_developer_privs => 'ADMIN:CREATE:DATA_LOADER:EDIT:HELP:MONITOR:SQL');

    EXCEPTION
      WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error while creating ADMIN user for TPS tablespace - investigate immediately: ' || SQLCODE || ' - ' || SQLERRM);

    END;

    -----
    -- Set application import variables:
    ----
    BEGIN
        APEX_APPLICATION_INSTALL.SET_WORKSPACE(p_workspace => 'TPS');
        APEX_APPLICATION_INSTALL.SET_APPLICATION_ID(p_application_id => '301');
        APEX_APPLICATION_INSTALL.GENERATE_OFFSET;
        APEX_APPLICATION_INSTALL.SET_APPLICATION_ALIAS( 'F' || APEX_APPLICATION_INSTALL.GET_APPLICATION_ID );

    EXCEPTION
      WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error while setting application environment - investigate immediately: ' || SQLCODE || ' - ' || SQLERRM);

    END;
       
EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('Unexpected fatal error - investigate immediately: ' || SQLCODE || ' - ' || SQLERRM);

END;
/ 

-- Install application from import file using application id #301
@/home/oracle/examples/jsonrdv/f301.sql;

PROMPT Application #301 has been successfully loaded into TPS workspace

