/*
|| JRDV metadata
*/

-- JRDV attributes:
SELECT *
  FROM all_json_duality_views
 WHERE view_owner = 'HOL23C';

-- Tables underlying JRDVs:
SELECT *
  FROM all_json_duality_view_tabs
 WHERE view_owner = 'HOL23C';

-- Table columns underlying JRDVs:
SELECT *
  FROM all_json_duality_view_tab_cols
 WHERE view_owner = 'HOL23C';

-- Relationships between tables comprising JRDVs:
SELECT *
  FROM all_json_duality_view_links
 WHERE view_owner = 'HOL23C';
 
-- Using DBMS_JSON_SCHEMA.DESCRIBE():
SELECT 
  JSON_SERIALIZE(DBMS_JSON_SCHEMA.DESCRIBE('TEAM_ASSIGNMENTS_DV') PRETTY)
  AS team_assignments_dv_json_schema;

