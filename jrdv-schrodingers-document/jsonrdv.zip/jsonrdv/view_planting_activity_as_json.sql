/*
|| Script:  view_planting_activity_as_json.sql
|| Purpose: Displays current state of data underlying PLANTING_ACTIVITY_DV JRDV
|| Author:  Jim Czuprynski (Zero Defect Computing, Inc.)
*/

-- See all data within the JRDV
SET PAGESIZE 5000
SET LINESIZE 80
COL planting_deliveries HEADING "JSON (PRETTY)"

SELECT 
  JSON_SERIALIZE(data PRETTY) AS planting_deliveries
  FROM hol23c.planting_activity_dv;
