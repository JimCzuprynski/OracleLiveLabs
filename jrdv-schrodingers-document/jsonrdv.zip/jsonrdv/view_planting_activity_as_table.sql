/*
|| Script:  view_planting_delivery_as_table.sql
|| Purpose: Displays current state of data underlying PLANTING_ACTIVITY_DV JRDV
|| Author:  Jim Czuprynski (Zero Defect Computing, Inc.)
*/

-- Show data in tabular format
SELECT 
  dv.data.teamid
, dv.data.teamname
, JSON_VALUE(dv.data.contents, '$.features.properties[0].name') AS heatislandname
, dv.data.tree_id AS "TREE ID"
, dv.data.common_name AS "TREE NAME" 
, dv.data.tree_lat AS latitude 
, dv.data.tree_lng AS longitude 
, dv.data.plant_dt AS "PLANTED ON"
, dv.data.height_at_start AS height 
, dv.data.notes AS comments
  FROM hol23c.planting_activity_dv DV;
