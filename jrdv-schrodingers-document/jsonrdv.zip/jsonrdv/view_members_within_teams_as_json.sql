/*
|| Script:  view_members_within_teams_as_json.sql
|| Purpose: Displays current state of data underlying MEMBERS_WITH_TEAMS_DV JRDV
|| Author:  Jim Czuprynski (Zero Defect Computing, Inc.)
*/

-- See all data within the JRDV
SET PAGESIZE 5000
SET LINESIZE 80
COL team_assignments HEADING "JSON (PRETTY)"

SELECT 
  JSON_SERIALIZE(data PRETTY) AS members_within_teams
  FROM hol23c.members_within_teams_dv;

