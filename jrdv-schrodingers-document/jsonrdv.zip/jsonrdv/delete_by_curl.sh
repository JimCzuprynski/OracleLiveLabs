######
# Script:  delete_by_curl.sh
# Purpose: Removes existing data elements within JRDVs by CURL DELETE calls
# Author:  Jim Czuprynski (Zero Defect Computing, Inc.)
#####

# Delete mutiple rows (those matching its PK for TEAM_ID of 401) from TEAM_ASSIGNMENTS_DV 
curl --request DELETE --url http://localhost:8080/ords/hol23c/team_assignments_dv/401

# Delete a single row from PLANTING_ACTIVITY_DV. 
# Note that key values for the underlying table are comma-delimited and specified in PK order
curl --request DELETE --url http://localhost:8080/ords/hol23c/planting_activity_dv/17031560300,101,"ACRU",41.8035,-87.7478


