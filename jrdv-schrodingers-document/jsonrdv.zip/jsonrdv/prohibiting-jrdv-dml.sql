INSERT INTO hol23c.members_within_teams_dv
VALUES ('  {"memberid"       : 5001
           ,"mbr_fname"      : "Noah"
           ,"mbr_lname"      : "NoHow"
           ,"mbr_addr"       : "1059 W. 32nd Street"
           ,"mbr_city"       : "Chicago"
           ,"mbr_state"      : "IL"
           ,"mbr_zipcode"    : "60608"
           ,"mbr_lat"        :  41.83593692161574
           ,"mbr_lng"        : -87.6533448345205 
           ,"teamid"         : 501
           ,"teamname"       : "TreeHuggers, LLC"
           ,"teamleadcontact": 5001
           }'
         );

COMMIT;