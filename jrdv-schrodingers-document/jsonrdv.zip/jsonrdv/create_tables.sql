/*
|| Script:  create_tables.sql
|| Purpose: Creates all required tables for demonstrating JRDV capabilities
|| Author:  Jim Czuprynski (Zero Defect Computing, Inc.)
*/

DROP TABLE IF EXISTS hol23c.planting_schedule;
DROP TABLE IF EXISTS hol23c.team_members;
DROP TABLE IF EXISTS hol23c.inventory;
DROP TABLE IF EXISTS hol23c.trees;
DROP TABLE IF EXISTS hol23c.teams;
DROP TABLE IF EXISTS hol23c.heat_islands;

CREATE TABLE IF NOT EXISTS hol23c.trees (	
   tr_id           VARCHAR2(06) NOT NULL
  ,tr_common_name  VARCHAR2(60) NOT NULL 
  ,tr_scient_name  VARCHAR2(60) NOT NULL 
  ,tr_type         VARCHAR2(20) NOT NULL 
  ,tr_avg_crown    NUMBER(15,4) NOT NULL
  ,tr_avg_height   NUMBER(15,4) NOT NULL
  ,tr_avg_max_age  NUMBER(8,2)  NOT NULL
);

CREATE TABLE IF NOT EXISTS hol23c.inventory (	
   in_tr_id        VARCHAR2(06) NOT NULL
  ,in_qty          NUMBER(8,0)  NOT NULL
  ,in_status       CHAR(03)     NOT NULL
);

CREATE TABLE IF NOT EXISTS hol23c.teams (	
   te_id           NUMBER(8,0)  NOT NULL
  ,te_name         VARCHAR2(60) NOT NULL
  ,te_lead_contact NUMBER(8,0)  NOT NULL
);

CREATE TABLE IF NOT EXISTS hol23c.team_members (	
   tm_id           NUMBER(8,0)  NOT NULL
  ,tm_te_id        NUMBER(8,0)  NOT NULL
  ,tm_first_name   VARCHAR2(40) NOT NULL
  ,tm_last_name    VARCHAR2(40) NOT NULL
  ,tm_address      VARCHAR2(40) NOT NULL
  ,tm_city         VARCHAR2(40) NOT NULL
  ,tm_state_abbr   VARCHAR2(02) NOT NULL
  ,tm_zip_code     CHAR(05)     NOT NULL
  ,tm_lat          NUMBER(8,6)  NOT NULL
  ,tm_lng          NUMBER(8,6)  NOT NULL
);

CREATE TABLE IF NOT EXISTS hol23c.heat_islands(	
   hi_id           NUMBER(11,0) NOT NULL
  ,hi_doc          JSON         NOT NULL 
); 

CREATE TABLE IF NOT EXISTS hol23c.planting_schedule (	
   ps_hi_id        NUMBER(11,0)     NOT NULL
  ,ps_te_id        NUMBER(8,0)      NOT NULL
  ,ps_tr_id        VARCHAR2(06)     NOT NULL
  ,ps_planted_on   DATE             NOT NULL
  ,ps_height       NUMBER(8,3)      NOT NULL
  ,ps_comments     VARCHAR2(4000)
  ,ps_lat          NUMBER(20,15)    NOT NULL
  ,ps_lng          NUMBER(20,15)    NOT NULL
  ,ps_geometry     SDO_GEOMETRY
);


-----
-- Add trigger to PLANTING_SCHEDULE to update PS_GEOMETRY column automatically
-----

CREATE OR REPLACE TRIGGER hol23c.trg_bi_planting_schedule
    BEFORE INSERT ON hol23c.planting_schedule
    FOR EACH ROW
BEGIN
   :NEW.ps_geometry := MDSYS.SDO_GEOMETRY(2001, 4326, MDSYS.SDO_POINT_TYPE(:NEW.ps_lng, :NEW.ps_lat, NULL), NULL, NULL);
END;
/

-----
-- Load tables
-----

SET LOAD TRUNCATE ON
SET LOADFORMAT DEFAULT
LOAD trees /home/oracle/examples/jsonrdv/trees.csv             
LOAD inventory /home/oracle/examples/jsonrdv/inventory.csv
LOAD teams /home/oracle/examples/jsonrdv/teams.csv         
LOAD team_members /home/oracle/examples/jsonrdv/team_members.csv

SET LOADFORMAT DELIMITER ^
LOAD heat_islands /home/oracle/examples/jsonrdv/heat_islands.dlm

@/home/oracle/examples/jsonrdv/load_planting_schedule.sql;

--------------------------------------------------------
-- Add PK constraints
--------------------------------------------------------

ALTER TABLE hol23c.trees
  ADD CONSTRAINT trees_pk 
    PRIMARY KEY (tr_id)
    USING INDEX (
      CREATE UNIQUE INDEX hol23c.trees_pk_idx 
        ON hol23c.trees (tr_id) 
        COMPUTE STATISTICS);
           
ALTER TABLE hol23c.inventory
  ADD CONSTRAINT inventory_pk 
    PRIMARY KEY (in_tr_id)
    USING INDEX (
      CREATE UNIQUE INDEX hol23c.inventory_pk_idx 
        ON hol23c.inventory (in_tr_id) 
        COMPUTE STATISTICS);

ALTER TABLE hol23c.teams
  ADD CONSTRAINT teams_pk 
    PRIMARY KEY (te_id)
    USING INDEX (
      CREATE UNIQUE INDEX hol23c.teams_pk_idx 
        ON hol23c.teams (te_id) 
        COMPUTE STATISTICS);

ALTER TABLE hol23c.team_members
  ADD CONSTRAINT team_members_pk 
    PRIMARY KEY (tm_id)
    USING INDEX (
      CREATE UNIQUE INDEX hol23c.team_members_pk_idx 
        ON hol23c.team_members (tm_id) 
        COMPUTE STATISTICS);

ALTER TABLE hol23c.heat_islands
  ADD CONSTRAINT heat_islands_pk 
    PRIMARY KEY (hi_id)
    USING INDEX (
      CREATE UNIQUE INDEX hol23c.heat_islands_pk_idx 
        ON hol23c.heat_islands (hi_id) 
        COMPUTE STATISTICS);
           
ALTER TABLE hol23c.planting_schedule
  ADD CONSTRAINT planting_schedule_pk 
    PRIMARY KEY (ps_hi_id, ps_te_id, ps_tr_id, ps_lat, ps_lng)
    USING INDEX (
      CREATE UNIQUE INDEX hol23c.planting_schedule_pk_idx 
        ON hol23c.planting_schedule (ps_hi_id, ps_te_id, ps_tr_id, ps_lat, ps_lng) 
        COMPUTE STATISTICS);

--------------------------------------------------------
-- Add FK constraints
--------------------------------------------------------

ALTER TABLE hol23c.inventory
  ADD CONSTRAINT in_tr_fk
    FOREIGN KEY (in_tr_id)
    REFERENCES hol23c.trees (tr_id);

ALTER TABLE hol23c.team_members
  ADD CONSTRAINT tm_te_fk
    FOREIGN KEY (tm_te_id)
    REFERENCES hol23c.teams (te_id);

ALTER TABLE hol23c.planting_schedule
  ADD CONSTRAINT ps_hi_fk
    FOREIGN KEY (ps_hi_id)
    REFERENCES hol23c.heat_islands (hi_id);

ALTER TABLE hol23c.planting_schedule
  ADD CONSTRAINT ps_te_fk
    FOREIGN KEY (ps_te_id)
    REFERENCES hol23c.teams (te_id);

ALTER TABLE hol23c.planting_schedule
  ADD CONSTRAINT ps_tr_fk
    FOREIGN KEY (ps_tr_id)
    REFERENCES hol23c.trees (tr_id);

--------------------------------------------------------
-- Add spatial indexes
--------------------------------------------------------

CREATE INDEX hol23c.planting_schedule_ps_geometry_spidx
  ON hol23c.planting_schedule (ps_geometry)
  INDEXTYPE IS MDSYS.SPATIAL_INDEX_V2;
