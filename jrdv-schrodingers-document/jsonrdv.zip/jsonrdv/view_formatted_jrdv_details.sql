-----
-- Different ways to see JRDV-defined data with JSON functions
-----
SET PAGESIZE 5000
SET LINESIZE 132

SELECT JSON_SERIALIZE(data) AS json_doc
  FROM hol23c.planting_activity_dv;

SELECT JSON_SERIALIZE(data PRETTY) AS json_doc
  FROM hol23c.planting_activity_dv;

SELECT JSON_SERIALIZE(data PRETTY ORDERED) AS json_doc
  FROM hol23c.planting_activity_dv;

